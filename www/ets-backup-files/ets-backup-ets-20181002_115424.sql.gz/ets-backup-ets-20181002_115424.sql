CREATE DATABASE IF NOT EXISTS `ets`;

USE `ets`;

DROP TABLE IF EXISTS `allowances`;

CREATE TABLE `allowances` (
  `allid` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`allid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `assignmodule`;

CREATE TABLE `assignmodule` (
  `courseID` varchar(10) NOT NULL,
  `moduleID` varchar(10) NOT NULL,
  PRIMARY KEY (`courseID`,`moduleID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `assignmodule` VALUES("001","E1013");
INSERT INTO `assignmodule` VALUES("001","IT1010");
INSERT INTO `assignmodule` VALUES("001","IT1015");
INSERT INTO `assignmodule` VALUES("002","ET1012");
INSERT INTO `assignmodule` VALUES("002","IT1013");



DROP TABLE IF EXISTS `authlevels`;

CREATE TABLE `authlevels` (
  `authId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(500) NOT NULL,
  `studentManagement` tinyint(1) NOT NULL DEFAULT '0',
  `financialManagement` tinyint(1) NOT NULL DEFAULT '0',
  `inventoryManagemnt` tinyint(1) NOT NULL DEFAULT '0',
  `courseManagemnt` tinyint(1) NOT NULL DEFAULT '0',
  `libraryManagement` tinyint(1) DEFAULT '0',
  `staffManagement` tinyint(1) NOT NULL DEFAULT '0',
  `administration` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `studentBasic` tinyint(1) NOT NULL DEFAULT '0',
  `staffBasic` tinyint(1) NOT NULL DEFAULT '0',
  `InventoryBasic` tinyint(1) NOT NULL DEFAULT '0',
  `libraryBasic` tinyint(1) NOT NULL DEFAULT '0',
  `attendance` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`authId`),
  UNIQUE KEY `authId` (`authId`),
  UNIQUE KEY `authId_2` (`authId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `authlevels` VALUES("1","Main Admin","2018-07-26 10:37:50","This auth level is assigned for the main Administrator","0","0","0","0","0","0","1","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("2","Course Administrator","2018-08-26 22:13:57","","0","0","0","0","0","0","0","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("3","Library Manager","2018-08-29 22:50:55","","0","0","0","0","1","0","0","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("4","Financial Manager","2018-08-26 22:14:32","","0","1","0","0","0","0","0","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("5","Inventory Manager","2018-08-29 22:51:35","","0","0","1","0","0","0","0","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("6","Staff Manager","2018-08-29 22:50:55","","1","0","0","0","0","0","0","0","0","0","0","0","0");
INSERT INTO `authlevels` VALUES("7","Attendance Manager","2018-08-29 22:48:25","","0","0","0","0","0","0","0","0","1","1","0","0","1");
INSERT INTO `authlevels` VALUES("8","Student Admin","2018-08-29 22:48:25","","1","0","0","0","0","0","0","0","0","0","0","0","0");



DROP TABLE IF EXISTS `author`;

CREATE TABLE `author` (
  `isbn` char(13) NOT NULL,
  `name` varchar(250) NOT NULL,
  PRIMARY KEY (`isbn`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `author` VALUES("1234567890111","J.D Samuels");
INSERT INTO `author` VALUES("b12031","A.A. Milne");
INSERT INTO `author` VALUES("td4556","H.G. Wells ");
INSERT INTO `author` VALUES("yh12546","F. Scott Fitzgerald");



DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `billNo` varchar(20) NOT NULL,
  `category` varchar(50) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `bills` VALUES("0000002","rent","2018-08-25 11:30:26","5","1000","1");
INSERT INTO `bills` VALUES("","","2018-08-30 11:27:24","6","0","1");
INSERT INTO `bills` VALUES("","","2018-10-02 06:46:33","7","10","1");
INSERT INTO `bills` VALUES("","","2018-10-01 15:51:04","8","0","0");
INSERT INTO `bills` VALUES("","","2018-10-02 06:46:12","9","0","1");
INSERT INTO `bills` VALUES("","","2018-10-02 06:46:16","10","0","1");



DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `isbn` char(13) NOT NULL,
  `title` varchar(250) NOT NULL,
  `edition` int(11) NOT NULL,
  `yearPublished` int(11) NOT NULL,
  `pages` int(11) NOT NULL,
  `description` varchar(250) NOT NULL,
  `callNumber` varchar(5) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `author` varchar(250) NOT NULL,
  PRIMARY KEY (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `book` VALUES("9781598215162","Software Engineering for Undergraduates","3","2011","1100","A complete course on software design and engineering","1233","2018-09-29 06:11:09","P.Tannebaum");
INSERT INTO `book` VALUES("9783598151386","Networking Basics","3","2009","222","Networking and Security 1","1223","2018-09-29 06:16:27","P.Tannebaum");
INSERT INTO `book` VALUES("9783598215049","Introduction to Programming","2","2001","354","Programming basics for undergraduates","123","2018-09-29 05:34:42","C.Dietel");
INSERT INTO `book` VALUES("9783598215050","Advanced Networking","3","2001","222","Networking 2","540","2018-09-29 06:20:06","P.Tannebaum");
INSERT INTO `book` VALUES("9783598215051","Introduction to Databases","3","2001","354","Database Theory","6305","2018-09-29 06:17:46","S.P.Navanthe");
INSERT INTO `book` VALUES("9783598215055","Java Programming","2","2009","354","Programming in Java","1233","2018-09-29 06:18:57","Rob Wield");
INSERT INTO `book` VALUES("9783598215056","Computer Science Basics","3","2010","333","Computer Science Basics","1234","2018-09-29 05:37:01","J.D.Salinger");
INSERT INTO `book` VALUES("9783598215057","History of Computing","3","2011","150","A brief history on the development of computing","12344","2018-09-29 05:49:53","J.D.Salinger");
INSERT INTO `book` VALUES("9783598215148","Advanced Mathematics","0","0","0","Schaums outline Series","1239","2018-09-29 06:03:56","P.Schaum");
INSERT INTO `book` VALUES("9783598215155","Algorithms and Data Structures","5","1997","123","Advanced Mathematics","6301","2018-09-29 06:08:53","Ricardo A.Bates");



DROP TABLE IF EXISTS `booktype`;

CREATE TABLE `booktype` (
  `isbn` varchar(12) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `center`;

CREATE TABLE `center` (
  `centerID` char(12) NOT NULL,
  `centername` varchar(25) NOT NULL,
  `staffID` char(12) NOT NULL,
  `address` varchar(250) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateUpdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`centerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `center` VALUES("1000","ETS Kegalle center","SFKGMA001563","","2018-08-25 15:19:01","0000-00-00 00:00:00");
INSERT INTO `center` VALUES("1001","ETS kurunagela center","SFKGAD001326","","2018-08-25 15:19:01","0000-00-00 00:00:00");



DROP TABLE IF EXISTS `copy`;

CREATE TABLE `copy` (
  `copyID` int(11) NOT NULL,
  `isbn` char(13) NOT NULL,
  PRIMARY KEY (`copyID`,`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `copy` VALUES("0","1234567890111");
INSERT INTO `copy` VALUES("1","yh1246");
INSERT INTO `copy` VALUES("2","b12031");
INSERT INTO `copy` VALUES("3","yh12546");
INSERT INTO `copy` VALUES("4","b12031");
INSERT INTO `copy` VALUES("5","td4556");



DROP TABLE IF EXISTS `courieragentdetails`;

CREATE TABLE `courieragentdetails` (
  `agentId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `courierdetails`;

CREATE TABLE `courierdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentID` char(3) NOT NULL,
  `staffID` char(12) NOT NULL,
  `dateSent` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `receiver` varchar(250) NOT NULL,
  `postcode` int(11) NOT NULL,
  `weight` varchar(25) NOT NULL,
  `value` varchar(25) NOT NULL,
  `qty` int(11) NOT NULL,
  `oriaddress` varchar(50) NOT NULL,
  `desaddress` varchar(50) NOT NULL,
  `description` varchar(250) NOT NULL DEFAULT 'Unknown',
  `service` varchar(30) NOT NULL,
  `agentname` varchar(30) NOT NULL,
  `contact` int(10) NOT NULL,
  `track` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `courierdetails` VALUES("11","A02","SFABCD234675","2018-10-04 00:00:00","johnharl@gmail.com","51346","400g","450LKR","35","Ets campus,No-24,peradeniya road,kandy","Ets campus,No-32,kandy road,kurunegala","2nd year 2nd semester model,Papers (IT1020)","DHL Express","","712525639","0");
INSERT INTO `courierdetails` VALUES("12","A03","SFABCD122345","2018-10-07 00:00:00","SachindaRuks@gmail.com","56872","1.5KG","700LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No:314,kandy road,kegalle","Statictics(Referance books)","DHL Express","","712525634","0");
INSERT INTO `courierdetails` VALUES("13","A04","SFABCD235678","2018-08-15 00:00:00","Lakshanwaruna@gmail.com","67342","2.5KG","3000LKR","0","Ets campus,No-24,peradeniya road,kandy","Ets campus,No:314,kandy road,kegalle","Staff","Certis Lanka","","712525634","0");
INSERT INTO `courierdetails` VALUES("14","A05","SFKGLE001554","2018-06-08 00:00:00","Indikakumara@gmail.com","45624","1.6kg","450LKR","0","Ets campus,No-24,peradeniya road,kandy","Ets campus,No:314,kandy road,kegalle","Python(Reference books)","DHL Express","","712525634","0");
INSERT INTO `courierdetails` VALUES("15","A05","SFABCD234643","2018-09-04 00:00:00","Chamodhhasintha@gmail.com","67342","2.5KG","450LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No:314,kandy road,kegalle","Papres(IT5060)","Pronto Lanka","","712525634","0");
INSERT INTO `courierdetails` VALUES("16","A06","SFABCD234634","2018-08-09 00:00:00","jayasinghe@gmail.com","51346","2.5KG","3000LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No:314,kandy road,kegalle","Staff material","DHL Express","","712525639","0");
INSERT INTO `courierdetails` VALUES("17","A07","SFABCD123346","2018-10-04 00:00:00","JamesNicholson@gmail.com","67342","2.5KG","350LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No:314,kandy road,kegalle","Final year papers(IT8090)","Certis Lanka","","712525634","0");
INSERT INTO `courierdetails` VALUES("18","A14","SFABCD123412","2018-10-09 00:00:00","TylerWatkins@gmail.com","45672","400g","350LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No:314,kandy road,kegalle","For Reception","Certis Lanka","","712525634","0");
INSERT INTO `courierdetails` VALUES("19","A12","SFABCD234623","2018-06-07 00:00:00","TomosCorrea@gmail.com","45624","1kg","450LKR","0","Ets campus,No-32,kandy road,kurunegala","Ets campus,No-24,peradeniya road,kandy","Books for (IT4509)","Certis Lanka","","712525639","0");
INSERT INTO `courierdetails` VALUES("20","A11","SFABCD234675","2018-07-04 00:00:00","DavidHealy@gmail.com","51346","1.6kg","350LKR","0","Ets campus,No-24,peradeniya road,kandy","Ets campus,No:314,kandy road,kegalle","For Staff","DHL Express","","712525634","0");



DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `courseID` varchar(10) NOT NULL,
  `cName` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `preQualification` varchar(100) NOT NULL,
  `postQualification` varchar(100) NOT NULL,
  `duration` int(11) NOT NULL,
  `commencingDate` date NOT NULL,
  `feePerSemester` double NOT NULL,
  `category` tinyint(1) NOT NULL,
  `dateUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`courseID`),
  UNIQUE KEY `courseID` (`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `course` VALUES("001","Bachelors degree in information and technology","its a it degree course","hjuk gggg gtef fddgt gbfg gd  vdf dff","jhjuk gggg gtef fddgt gbfg gd  vdf dff","48","2018-08-31","200000","1","2018-08-25 06:39:03","1");
INSERT INTO `course` VALUES("002","Bachelor of Civil Engineering Technology","this is an engineering course","hgf hgfd hgf gfd hgfd gf gfr","ett tt ytt hhh vrd hgf gf hgfd hgf hgf jhgf ","36","2018-09-11","250000","1","2018-08-25 06:39:03","1");
INSERT INTO `course` VALUES("003","certifcate course in computing","Its a certificate course lkmdjh kjh jh","finished ordinary level","sscdasd sdad","6","2018-08-06","2000","3","2018-08-25 08:21:35","1");
INSERT INTO `course` VALUES("BM06"," Bachelor of Science (BSc) in Accounting","Its a Bachelors degree in accounting science.","A/L with three B passes in maths or commerce stream","-","48","2019-01-17","134000","1","2018-10-02 00:10:01","1");
INSERT INTO `course` VALUES("BM07","Bachelor of Accountancy","Its a Bachelour degree in Accounting","A/L with three B passes in maths or commerce stream","-","35","2019-01-09","150000","1","2018-10-02 00:06:47","1");
INSERT INTO `course` VALUES("CT06","Higher National Diploma in QS","Ita a Higher National Diploma relates to construction Tecnology","A/L or O/L with foundation course","none","36","2018-10-18","50000","2","2018-10-01 23:53:46","1");
INSERT INTO `course` VALUES("CT07","Quantity Surveying - Full Time","Its a diploma Based on construction technology","A/L","-","10","2018-10-17","10000","2","2018-10-02 00:00:44","1");
INSERT INTO `course` VALUES("ET06"," Bachelor of Civil Engineering Technology  "," Civil engineering technologists plan, design and supervise the construction of infrastructure and facilities.","A/L or O/L and Foundation Programe or Diploma","-","48","2018-10-16","23000","1","2018-10-01 23:50:24","1");
INSERT INTO `course` VALUES("IT01","Business in Information technology","BIT [1] is a three-year, co-op scholarship degree with two six-month job placements.","A/L","-","45","2018-09-11","250000","1","2018-10-02 01:15:36","1");
INSERT INTO `course` VALUES("IT02"," Bachelor of Science in Information Technology","conferred after a period of three to four years of an undergraduate course of study in Information Technology (IT).","A/L with at least 3 S passes","-","36","2018-10-09","275000","1","2018-10-01 23:29:25","1");
INSERT INTO `course` VALUES("IT03","Certificate in Information Technology","Its a Certificate course in information tecnology.","O/L","-","4","2018-10-11","6000","3","2018-10-01 23:40:55","1");
INSERT INTO `course` VALUES("IT04","Diploma in Information Technology","Its an Information Technology diploma course","O/L with at least three s passes","-","6","2019-01-08","5000","2","2018-10-01 23:43:11","1");
INSERT INTO `course` VALUES("IT05","Certificate in 3D Animation","Its a 3D Animation certificate  course","O/L","-","5","2018-11-07","3000","3","2018-10-01 23:45:18","1");
INSERT INTO `course` VALUES("IT06","h","h","h","h","5","0005-05-05","5","2","2018-10-02 01:21:34","1");



DROP TABLE IF EXISTS `coursecategory`;

CREATE TABLE `coursecategory` (
  `categoryId` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `coursecategory` VALUES("1","Degrees","It is a degree program");
INSERT INTO `coursecategory` VALUES("2","Diploma","It is a Diplpma program");
INSERT INTO `coursecategory` VALUES("3","Short Courses","It is a Short Courses program");



DROP TABLE IF EXISTS `coursematerial`;

CREATE TABLE `coursematerial` (
  `cmID` int(10) NOT NULL AUTO_INCREMENT,
  `moduleID` varchar(10) NOT NULL,
  `description` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `link` varchar(70) NOT NULL,
  PRIMARY KEY (`cmID`,`moduleID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `coursematerial` VALUES("1","ET1012","","2018-08-25 10:25:46","folder/space/sjns");
INSERT INTO `coursematerial` VALUES("2","IT1010","","2018-08-25 10:25:46","husag/kjnha/jss/");
INSERT INTO `coursematerial` VALUES("3","IT1015","","2018-08-25 10:25:46","dfdrg/drgrd/gdrrg");
INSERT INTO `coursematerial` VALUES("4","IT1015","","2018-08-25 10:25:46","fees/tty/gyhy/th");



DROP TABLE IF EXISTS `deductions`;

CREATE TABLE `deductions` (
  `deductid` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`deductid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `dependents`;

CREATE TABLE `dependents` (
  `staffID` char(12) NOT NULL,
  `name` varchar(50) NOT NULL,
  `relationship` varchar(25) NOT NULL,
  `bod` date DEFAULT NULL,
  `nic` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`staffID`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `dependents` VALUES("SFKGLE001552","anna kate","wife",NULL,NULL);
INSERT INTO `dependents` VALUES("SFKGMA001563","ella helen","daughter",NULL,NULL);



DROP TABLE IF EXISTS `emails`;

CREATE TABLE `emails` (
  `userId` char(12) NOT NULL,
  `email` varchar(250) NOT NULL,
  `subscribed` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userId`,`email`,`subscribed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `emails` VALUES("SFKGAD001325","asiri@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGAD001365","dfssooc@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGAD001366","dad@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGLE001552","erwerwttt@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGLE001553","sfadf@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGLE001564","wrerelee@gmail.com","1");
INSERT INTO `emails` VALUES("SFKGMA001563","fzsd@sgfg.com","1");
INSERT INTO `emails` VALUES("SFKGMA001567","wrewmm@gmail.com","1");



DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `ExamID` varchar(10) NOT NULL,
  `staffID` char(12) NOT NULL,
  `moduleID` varchar(10) NOT NULL,
  `courseID` varchar(10) NOT NULL,
  `dateTime` datetime NOT NULL,
  `duration` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`ExamID`,`moduleID`,`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `exam` VALUES("ET12","SFKGLE001553","ET1012","002","2018-08-25 15:22:50","0","0");
INSERT INTO `exam` VALUES("IT01 ","SFKGLE001552","IT1010","IT01","2018-10-01 16:50:02","0","0");
INSERT INTO `exam` VALUES("IT02","SFKGAD001325","E1013","IT01","2018-10-01 16:50:27","2","1");
INSERT INTO `exam` VALUES("IT03","SFKGLE001552","E1013","IT01","2018-10-01 16:50:15","4","1");
INSERT INTO `exam` VALUES("IT04","SFKGAD001325","E1013","IT02","2018-10-01 16:50:33","2","0");
INSERT INTO `exam` VALUES("IT05","SFKGAD001325","E1013","IT01","2018-10-01 16:50:20","4","1");
INSERT INTO `exam` VALUES("IT10 ","SFKGLE001552","IT1010","001","2018-08-25 15:22:50","0","0");
INSERT INTO `exam` VALUES("QS01","SFKGAD001325","E1013","QS02","2018-10-01 16:50:45","5","1");
INSERT INTO `exam` VALUES("QS02","SFKGAD001325","IT1010","QS01","2018-10-01 16:51:00","4","1");
INSERT INTO `exam` VALUES("QS03","SFKGAD001325","E1013","QS02","2018-10-01 16:50:38","1","1");
INSERT INTO `exam` VALUES("QS04","SFKGAD001325","E1013","QS01","2018-10-01 16:50:51","3","1");



DROP TABLE IF EXISTS `expenditure`;

CREATE TABLE `expenditure` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `expenditure` VALUES("1","pettycash","3000");
INSERT INTO `expenditure` VALUES("2","bills","200");



DROP TABLE IF EXISTS `financial`;

CREATE TABLE `financial` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `type` varchar(50) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `financial` VALUES("1","20000","New cash","2018-07-01 00:00:00");
INSERT INTO `financial` VALUES("2","30000","Regular cash","2018-08-01 00:00:00");



DROP TABLE IF EXISTS `guardian`;

CREATE TABLE `guardian` (
  `stuID` char(12) NOT NULL,
  `guardianID` char(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contactNo` varchar(10) NOT NULL,
  PRIMARY KEY (`stuID`,`guardianID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `guardian` VALUES("STKGET001212","GD0012","J.M. Barrie","076980236");
INSERT INTO `guardian` VALUES("STKGET001214","GD0015","L. Frank Baum","0723564987");
INSERT INTO `guardian` VALUES("STKGIT001284","GD0013","J.R.R. Tolkien","0725226963");
INSERT INTO `guardian` VALUES("STKGIT001452","GD0014","P.G. Wodehouse","0752546845");



DROP TABLE IF EXISTS `halls`;

CREATE TABLE `halls` (
  `centerID` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `hallId` int(11) NOT NULL,
  `description` varchar(250) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`centerID`,`hallId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `halls` VALUES("1000","lab","1015","","2018-08-25 15:24:56");
INSERT INTO `halls` VALUES("1000","lecture room","1016","","2018-08-25 15:24:56");
INSERT INTO `halls` VALUES("1000","lecture hall","1017","","2018-08-25 15:24:56");



DROP TABLE IF EXISTS `inquiry`;

CREATE TABLE `inquiry` (
  `inquaryID` int(11) NOT NULL AUTO_INCREMENT,
  `courseID` varchar(10) NOT NULL,
  `home` int(11) NOT NULL,
  `resident` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `response` varchar(500) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`inquaryID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `inquiry` VALUES("1","IT02","112546150","77254656","F. Scott Fitzgerald","CALL","CAHMI@gmail.com","NOT ANSWER","2018-10-02");
INSERT INTO `inquiry` VALUES("2","IT03","812649562","760251802","H.Howard Phillips","LETTER","Phillips@gmail.com","PAY REGISTRATION FEE","2018-09-02");
INSERT INTO `inquiry` VALUES("4","BM06","77134553","66757446","lakshan","LETTER","asd@gmail.com","call 0661234567 for more details","2018-08-02");
INSERT INTO `inquiry` VALUES("5","IT01","712442342","603453543","Sri Harish","CALL","yam@mail.com","pay Repeat registration fee","2018-07-02");
INSERT INTO `inquiry` VALUES("6","ET06","77423345","81324343","sak","VISIT","ASIRI@mail.com","not answer","2018-06-02");
INSERT INTO `inquiry` VALUES("7","CT07","726866567","823313332","jack black","CALL","ANUHASs@gmail.com","pay course fee","2018-05-02");
INSERT INTO `inquiry` VALUES("8","CT06","773816581","813423443","rock","LETTER","lal@gmail.com","not answer","2018-04-02");
INSERT INTO `inquiry` VALUES("9","IT01","768348938","668738733","rose","CALL","banda@mail.com","not answer","2018-03-02");
INSERT INTO `inquiry` VALUES("10","IT02","713131122","608787388","manika","CALL","spoe@mail.com","pay registration fee","2018-02-02");
INSERT INTO `inquiry` VALUES("11","IT01","352278765","77254656","Anuhas divlage","CALL","anuhas@gmail.com","not registered","2018-01-02");
INSERT INTO `inquiry` VALUES("12","IT01","352234567","778181540","Chami Subasinghe","VISIT","chami@gmail.com","pay registration fee","2018-10-02");



DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hallID` varchar(25) NOT NULL,
  `type` varchar(25) NOT NULL,
  `status` varchar(30) NOT NULL,
  `center` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(30) NOT NULL,
  `SupName` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` int(10) NOT NULL,
  `Description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

INSERT INTO `items` VALUES("5","H001","Other","In use","Kandy","2018-10-10","Book","test","senulprabash@gmail.com","786141343","edfs");
INSERT INTO `items` VALUES("53","H001","Electric","In use","Kandy","2018-09-04","Computer","David Healy","DavidHealy@gmail.com","771265895","");
INSERT INTO `items` VALUES("54","H002","Electric","In use","Kegalla","2018-09-03","Printer","John Mccabe","JohnMccabe@gmail.com","771265356","");
INSERT INTO `items` VALUES("55","H003","Furniture","In use","Kurunegala","2018-09-04","Computer table","James Nicholson","JamesNicholson@gmail.com","771265845","");
INSERT INTO `items` VALUES("56","H003","Furniture","In use","Kandy","2018-07-19","Table","Samuel Mayo","SamuelMayo@gmail.com","771265673","");
INSERT INTO `items` VALUES("57","H003","Electric","In use","Kegalla","2018-08-09","Scanner","Tyler Watkins","TylerWatkins@gmail.com","771265356","");
INSERT INTO `items` VALUES("58","H003","Electric","In use","Kurunegala","2018-08-16","Computer","Macauley Feeney","MacauleyFeeney@gmail.com","771265673","");
INSERT INTO `items` VALUES("59","H003","Furniture","In use","Kandy","2018-10-04","Table","David Healy","DavidHealy@gmail.com","771265356","");
INSERT INTO `items` VALUES("60","H003","Electric","In use","Kurunegala","2018-10-05","Printer","Samuel Mayo","SamuelMayo@gmail.com","771265673","");
INSERT INTO `items` VALUES("61","H003","Furniture","In use","Kandy","2018-07-25","Table","James Nicholson","JamesNicholson@gmail.com","771265673","");
INSERT INTO `items` VALUES("62","H003","Electric","In use","Kurunegala","2018-10-03","Scanner","Samuel Mayo","SamuelMayo@gmail.com","771265356","");



DROP TABLE IF EXISTS `jobtype`;

CREATE TABLE `jobtype` (
  `jobtypeid` int(11) NOT NULL,
  `jobtypename` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`jobtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `jobtype` VALUES("1","permenent");
INSERT INTO `jobtype` VALUES("2","contract");
INSERT INTO `jobtype` VALUES("3","partTime");



DROP TABLE IF EXISTS `libraryborrow`;

CREATE TABLE `libraryborrow` (
  `isbn` char(13) NOT NULL,
  `memberId` char(12) NOT NULL,
  `dateBorrowed` date NOT NULL,
  `dateReturned` date NOT NULL,
  `fine` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`isbn`,`memberId`,`dateBorrowed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `libraryborrow` VALUES("1234567890123","SFGKLE001122","2018-08-25","2018-09-29","1750");
INSERT INTO `libraryborrow` VALUES("1234567890123","SFGKLE001122","2018-09-01","2018-10-02","1550");
INSERT INTO `libraryborrow` VALUES("1234567890123","SFKGLE001599","2018-10-30","0000-00-00","0");
INSERT INTO `libraryborrow` VALUES("1234567890123","SFKGLE002277","2018-09-15","2018-09-29","700");
INSERT INTO `libraryborrow` VALUES("978159821516","SFKGLE002277","2018-09-01","0000-00-00","0");
INSERT INTO `libraryborrow` VALUES("978359815138","SFKGLE002277","2018-09-01","2018-09-09","50");
INSERT INTO `libraryborrow` VALUES("978359821504","SFKGLE002297","2018-09-04","2018-09-10","0");
INSERT INTO `libraryborrow` VALUES("978359821505","SFKGLE002297","2018-09-09","2018-09-23","350");
INSERT INTO `libraryborrow` VALUES("978359821505","SFKGLE002298","2018-09-01","2018-09-11","150");
INSERT INTO `libraryborrow` VALUES("978359821505","SFKGLE002298","2018-09-12","2018-09-27","220");
INSERT INTO `libraryborrow` VALUES("978359821505","SFKGLE002298","2018-09-23","2018-09-30","0");
INSERT INTO `libraryborrow` VALUES("978359821505","STKGBM001144","2018-09-11","2018-09-20","200");
INSERT INTO `libraryborrow` VALUES("978359821514","SFKGLE002298","2018-09-15","2018-09-22","0");
INSERT INTO `libraryborrow` VALUES("978359821514","SFKGLE002298","2018-09-19","2018-09-28","100");



DROP TABLE IF EXISTS `maincash`;

CREATE TABLE `maincash` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `bankDate` date NOT NULL,
  `slipNo` varchar(30) NOT NULL,
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `maincash` VALUES("1","2018-08-15","0000001");
INSERT INTO `maincash` VALUES("2","2018-08-22","0000002");



DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `moduleID` varchar(10) NOT NULL,
  `mName` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `credits` int(11) DEFAULT NULL,
  PRIMARY KEY (`moduleID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `module` VALUES("BM1024","Basic conceps in accountancy","BM module in accountancy","2018-10-02 01:03:19","0","3");
INSERT INTO `module` VALUES("CT1024","construction tecnology","Module in Construction Tecnology","2018-10-02 00:19:26","1","3");
INSERT INTO `module` VALUES("CT1025","Design Principles & Application for Construction and the Built Environment","Module in HNDQS","2018-10-02 00:21:55","1","4");
INSERT INTO `module` VALUES("E1013","English for accademic purpose","Its a english module","2018-08-25 06:54:18","0",NULL);
INSERT INTO `module` VALUES("ET1012","engineering basics functionalities","Its a engineering module","2018-08-25 06:47:54","0",NULL);
INSERT INTO `module` VALUES("ET1017","engineering basics functionalities","Its a engineering module","2018-10-01 13:30:53","0","3");
INSERT INTO `module` VALUES("IT1010","Computer networking and data administration","It is a module of Computer networking","2018-08-25 00:00:00","0",NULL);
INSERT INTO `module` VALUES("IT1015","Internet and web Technologies","its a web Technologies module","2018-08-25 06:48:50","0",NULL);
INSERT INTO `module` VALUES("IT1020","Discrete Mathematics","IT module in Discrete Mathematics","2018-10-02 00:16:12","1","4");
INSERT INTO `module` VALUES("IT1022","Basic computer Architecture","IT module about computer Architecture","2018-10-02 00:15:00","1","4");
INSERT INTO `module` VALUES("IT1023","Java programing","IT module in Java programing","2018-10-02 00:17:13","1","3");
INSERT INTO `module` VALUES("IT1027","Internet fundermentals and applications","IT Module in Internet fundermentals","2018-10-02 00:13:37","1","3");



DROP TABLE IF EXISTS `perform`;

CREATE TABLE `perform` (
  `staffID` char(12) NOT NULL,
  `month` varchar(50) DEFAULT NULL,
  `accuracy` int(11) DEFAULT NULL,
  `accuracycom` varchar(200) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `speedcom` varchar(200) DEFAULT NULL,
  `jobknow` int(11) DEFAULT NULL,
  `jobknowcom` varchar(200) DEFAULT NULL,
  `qow` int(11) DEFAULT NULL,
  `qowcom` varchar(200) DEFAULT NULL,
  `inititive` int(11) DEFAULT NULL,
  `inititivecom` varchar(200) DEFAULT NULL,
  `communication` int(11) DEFAULT NULL,
  `communicationcom` varchar(200) DEFAULT NULL,
  `commensense` int(11) DEFAULT NULL,
  `commenSensecom` varchar(200) DEFAULT NULL,
  `app` int(11) DEFAULT NULL,
  `appcom` varchar(200) DEFAULT NULL,
  `corp` int(11) DEFAULT NULL,
  `corpcom` varchar(200) DEFAULT NULL,
  `cs` int(11) DEFAULT NULL,
  `cscom` varchar(200) DEFAULT NULL,
  `conduct` int(11) DEFAULT NULL,
  `othercom` varchar(200) DEFAULT NULL,
  `entered` varchar(12) DEFAULT NULL,
  `review` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `performance`;

CREATE TABLE `performance` (
  `staffID` int(11) NOT NULL,
  `performanceID` int(11) NOT NULL,
  PRIMARY KEY (`staffID`,`performanceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `pettycash`;

CREATE TABLE `pettycash` (
  `category` varchar(300) NOT NULL,
  `reciptID` varchar(300) NOT NULL,
  `reason` varchar(300) NOT NULL,
  `currentBalance` double NOT NULL,
  `amountNeeded` double NOT NULL,
  `amountRecieved` double NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`transactionID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `pettycash` VALUES("","","","5000","3000","5000","2018-08-25 11:31:43","1");
INSERT INTO `pettycash` VALUES("","","","3000","2000","5000","2018-08-25 11:32:07","2");
INSERT INTO `pettycash` VALUES("","","","2000","2500","5000","2018-08-25 11:32:39","3");
INSERT INTO `pettycash` VALUES("","","edf","0","3","33","2018-08-30 11:13:49","4");
INSERT INTO `pettycash` VALUES("","","buy books","0","570","5000","2018-08-30 11:15:38","5");
INSERT INTO `pettycash` VALUES("Office materials","34535","","3","35","343","2018-10-02 06:48:56","6");



DROP TABLE IF EXISTS `phones`;

CREATE TABLE `phones` (
  `userId` char(12) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'mobile',
  `subscribed` tinyint(1) NOT NULL DEFAULT '1',
  `SMSKey` varchar(15) NOT NULL,
  PRIMARY KEY (`userId`,`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `phones` VALUES("SFKGAD001325","0786141343","mobile","1","dgte7wh8j37hj");
INSERT INTO `phones` VALUES("SFKGAD001365","0786161343","Mobile","1","");
INSERT INTO `phones` VALUES("SFKGAD001366","0786161343","Mobile","1","");
INSERT INTO `phones` VALUES("SFKGLE001552","0786161342","Mobile","1","");
INSERT INTO `phones` VALUES("SFKGLE001553","0721258930","Residence","1","");
INSERT INTO `phones` VALUES("SFKGLE001564","0721258931","Residence","1","");
INSERT INTO `phones` VALUES("SFKGMA001563","34363","mobile","1","");
INSERT INTO `phones` VALUES("SFKGMA001567","0786161343","Mobile","1","");
INSERT INTO `phones` VALUES("STKGIT001453","","","1","");
INSERT INTO `phones` VALUES("STKGIT001453","0786161343","Mobile","1","");
INSERT INTO `phones` VALUES("STKGIT001454","0721258930","Residence","1","");
INSERT INTO `phones` VALUES("STKGIT001455","0721258930","Residence","1","");
INSERT INTO `phones` VALUES("STKGIT001456","0721258930","Residence","1","");



DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `postid` int(11) NOT NULL,
  `postname` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `post` VALUES("1","Student Manager");
INSERT INTO `post` VALUES("2","Main Admin");
INSERT INTO `post` VALUES("3","Staff Member");
INSERT INTO `post` VALUES("4","Financial Manager");



DROP TABLE IF EXISTS `result`;

CREATE TABLE `result` (
  `examID` varchar(10) NOT NULL,
  `stuID` char(12) NOT NULL,
  `marks` double NOT NULL,
  `moduleID` varchar(12) NOT NULL,
  `courseID` varchar(15) NOT NULL,
  PRIMARY KEY (`examID`,`stuID`),
  KEY `stuID` (`stuID`),
  CONSTRAINT `result_ibfk_1` FOREIGN KEY (`stuID`) REFERENCES `student` (`stuID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `result` VALUES("ET12","STKGET001212","68","","IT01");
INSERT INTO `result` VALUES("ET13","STKGET001214","87","","IT01");
INSERT INTO `result` VALUES("IT10","STKGIT001284","75","","QS01");
INSERT INTO `result` VALUES("IT12","STKGIT001452","80","","QS01");
INSERT INTO `result` VALUES("QS01","STKGIT004444","89","","QS02");
INSERT INTO `result` VALUES("QS02","STKGET002222","67","","QS02");
INSERT INTO `result` VALUES("QS02","STKGIT001111","90","","QS01");
INSERT INTO `result` VALUES("QS02","STKGIT008888","39","","QS01");



DROP TABLE IF EXISTS `salary`;

CREATE TABLE `salary` (
  `staffID` char(12) NOT NULL,
  `salaryID` varchar(10) NOT NULL,
  `pay` tinyint(1) NOT NULL,
  `payDate` date NOT NULL,
  `basic` double NOT NULL,
  `allowences` double NOT NULL,
  `deduction` double NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`staffID`,`salaryID`),
  CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `salary` VALUES("SFKGLE000000","","0","0000-00-00","50000","7000","2000","0");
INSERT INTO `salary` VALUES("SFKGLE000001","","0","0000-00-00","45000","5000","2000","0");
INSERT INTO `salary` VALUES("SFKGLE000005","","0","0000-00-00","25000","5000","2000","0");
INSERT INTO `salary` VALUES("SFKGLE000006","","0","0000-00-00","50000","10000","5000","0");
INSERT INTO `salary` VALUES("SFKGLE000007","","0","0000-00-00","50000","2200","1000","0");
INSERT INTO `salary` VALUES("SFKGLE000009","","0","0000-00-00","70000","120000","7000","0");
INSERT INTO `salary` VALUES("SFKGLE001552","10300000","1","2018-08-23","18000","4000","700","21300");
INSERT INTO `salary` VALUES("SFKGMA001563","10200000","1","2018-08-22","20000","5000","500","24500");
INSERT INTO `salary` VALUES("SFKGMA001569","","0","0000-00-00","25000","5000","2000","0");



DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `varId` int(11) NOT NULL AUTO_INCREMENT,
  `variable` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'text',
  `value` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `static` tinyint(1) DEFAULT '2',
  PRIMARY KEY (`varId`),
  UNIQUE KEY `variable` (`variable`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO `settings` VALUES("3","Owner","","text","ETS Campus","2018-08-06 14:59:31","2018-08-26 23:10:54","2");
INSERT INTO `settings` VALUES("4","payments","","text","enabled","2018-07-23 21:29:06","2018-08-20 15:56:53","2");
INSERT INTO `settings` VALUES("5","System_Name","","text","ETS Management System","2018-08-06 12:48:36","2018-08-21 12:46:32","1");
INSERT INTO `settings` VALUES("6","Version","","number","6.7","2018-08-06 14:56:19","2018-09-29 18:50:02","1");
INSERT INTO `settings` VALUES("7","SMS_API","","text","","2018-08-02 08:28:07","2018-08-06 15:56:53","2");
INSERT INTO `settings` VALUES("8","USSD_API","","text","","2018-08-02 08:28:07","2018-08-06 15:56:53","2");
INSERT INTO `settings` VALUES("9","telco_password","","text","88abdb9fb3f7fad84f0b1a37a8d85772 ","2018-08-02 08:30:52","2018-08-06 15:56:53","2");
INSERT INTO `settings` VALUES("10","telco_appID","","text","APP_046159 ","2018-08-02 08:30:52","2018-08-06 15:56:53","2");
INSERT INTO `settings` VALUES("11","SMS_APP_ID","","text","APP_046159","2018-08-06 12:51:42","2018-08-06 15:56:53","2");
INSERT INTO `settings` VALUES("29","favicon_path","","text","logo.png","2018-08-06 15:38:14","2018-09-29 17:25:40","1");
INSERT INTO `settings` VALUES("31","theme_color_background","","text","blue","2018-08-06 16:27:51","2018-08-29 09:03:40","1");
INSERT INTO `settings` VALUES("32","custom_css","This variable shows the path to custom css","text","plugins/bootstrap-tagsinput/bootstrap-tagsinput.css","2018-08-06 20:02:39","2018-08-06 21:42:14","1");
INSERT INTO `settings` VALUES("38","hosting_size_mb","","text","1024","2018-08-10 18:53:41","2018-09-29 17:24:00","1");
INSERT INTO `settings` VALUES("39","enable_library","","number","1","2018-08-29 18:41:54","2018-09-29 17:24:11","1");



DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staffId` char(12) NOT NULL,
  `nameInFull` varchar(250) NOT NULL,
  `nameWithInit` varchar(150) NOT NULL,
  `managedBy` char(12) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `post` varchar(100) NOT NULL DEFAULT 'Staff Member',
  `dob` date NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `centerId` char(12) DEFAULT NULL,
  `thumb` varchar(150) NOT NULL DEFAULT 'images/icons/user.png',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `nic` varchar(10) NOT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `datejoined` date DEFAULT NULL,
  `jobtype` varchar(50) DEFAULT NULL,
  `maritalstatus` varchar(50) DEFAULT NULL,
  `jobstatus` varchar(20) NOT NULL DEFAULT 'Confirmed ',
  PRIMARY KEY (`staffId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staff` VALUES("SFKGAD001325","Asiri Hewage","H.A.S.S.P.Hewage","SFKGAD001325","1","Main Admin","1993-10-12","2018-08-25 15:14:35","2018-10-02 10:46:07","0","images/icons/user.png","1","961571162V","Srilankan","2018-10-09","permenent","Single","Confirmed ");
INSERT INTO `staff` VALUES("SFKGAD001365","Chamod H.","Chamod Brian","SFKGAD001325","1","Inventory Manager","1993-10-16","2018-08-29 21:01:10","2018-10-02 10:46:34",NULL,"images/icons/user.png","1","961571162V",NULL,"2018-10-12","permenent",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGAD001366","Lakshan","Lakshan David","SFKGAD001325","1","HR Manager","0000-00-00","2018-08-29 21:01:10","2018-10-02 10:46:37",NULL,"images/icons/user.png","1","961571162V",NULL,"2018-10-24","permenent",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGLE000000","Merill Kelmere","","SFKGLL000000","M","branchAdmin","1986-01-05","2018-09-29 03:28:08","2018-09-29 13:15:22",NULL,"uploads/SFLLLL000000.jpg","1","596811744V",NULL,"2017-02-07","permenent",NULL,"confirmed");
INSERT INTO `staff` VALUES("SFKGLE000001","Mattie Jeune","","SFKGLE000000","F","lecturer","2005-11-01","2018-09-29 03:59:37","2018-09-29 03:59:37",NULL,"uploads/SFKGLE000001.jpg","1","653222547V",NULL,"2017-02-10","contract",NULL,"probation");
INSERT INTO `staff` VALUES("SFKGLE000005","Simon Athukorala","","SFKGLE000000","M","lecturer","1986-02-02","2018-09-29 13:04:52","2018-09-29 13:04:52",NULL,"uploads/SFKGLE000005.jpg","1","951864846V",NULL,"2018-09-05","internship",NULL,"probation");
INSERT INTO `staff` VALUES("SFKGLE000006","Pasindu Wijerathna","","SFKGLE000000","M","accountant","2000-06-05","2018-09-29 13:16:53","2018-09-29 13:16:53",NULL,"uploads/SFKGLE000006.jpg","1","205156486V",NULL,"2018-09-04","permenent",NULL,"confirmed");
INSERT INTO `staff` VALUES("SFKGLE000007","Nvidia Silva","","SFKGLE000000","F","receptionst","1996-07-05","2018-09-30 05:55:32","2018-09-30 05:55:32",NULL,"uploads/SFKGLE000007.jpg","1","961846564V",NULL,"2018-09-02","contract",NULL,"probation");
INSERT INTO `staff` VALUES("SFKGLE000009","Bustin Weerarathne","","SFKGLE000000","M","accountant","1996-10-02","2018-10-01 01:43:00","2018-10-01 01:44:05",NULL,"uploads/SFKGLE000009.jpg","1","965247177V",NULL,"2017-01-02","permenent",NULL,"confirmed");
INSERT INTO `staff` VALUES("SFKGLE001552","Chamika","C. Subasinghe","SFKGAD001325","0","Student Affairs Officer","1993-01-17","2018-08-25 15:14:35","2018-10-02 10:46:42","0","images/icons/user.png","0","961571162V",NULL,"2018-10-03","partTime",NULL,"probation");
INSERT INTO `staff` VALUES("SFKGLE001553","Iresha Ganegala","G.W.I.K.Ganegala","SFKGAD001325","0","Lecturer","0000-00-00","2018-08-25 15:14:35","2018-10-02 10:17:52","0","images/icons/user.png","1","",NULL,NULL,"permenent",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGLE001564","Indika K.","Indika Kumara","SFKGAD001325","1","Financial Manager","1993-10-17","2018-08-29 20:51:53","2018-10-02 10:46:50",NULL,"images/icons/user.png","1","961571162V",NULL,"2018-10-17","permenent",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGMA001563","Lakshara P.","Laksara Perera","SFKGAD001325","1","Library Manager","0000-00-00","2018-08-25 15:14:35","2018-10-02 10:46:40","1","images/icons/user.png","1","961571162V",NULL,"2018-10-03","permenent",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGMA001567","\n\nAnuhas de silva","Anuhas D.S","SFKGAD001325",NULL,"Staff Member","0000-00-00","2018-08-29 22:44:58","2018-10-02 10:46:46",NULL,"images/icons/user.png","1","961571162V",NULL,"2018-10-01","contract",NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGMA001568","Anuhas De silva","Anuhas D.S.","SFKGAD001325",NULL,"Staff Member","0000-00-00","2018-08-29 22:44:25","2018-08-29 23:49:17",NULL,"images/icons/user.png","1","",NULL,NULL,NULL,NULL,"Confirmed ");
INSERT INTO `staff` VALUES("SFKGMA001569","Jacob Perera","","SFKGLE000000","M","receptionst","1996-02-01","2018-10-02 10:55:05","2018-10-02 10:55:05",NULL,"","1","966576413V",NULL,"2018-10-10","partTime",NULL,"confirmed");



DROP TABLE IF EXISTS `staffattendence`;

CREATE TABLE `staffattendence` (
  `staffID` char(12) NOT NULL,
  `present` tinyint(1) NOT NULL,
  `arrivalTime` time NOT NULL,
  `depatureTime` time NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`staffID`,`date`),
  CONSTRAINT `staffattendence_ibfk_1` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staffattendence` VALUES("SFKGAD001325","0","00:00:00","00:00:00","2018-08-25 09:13:35");
INSERT INTO `staffattendence` VALUES("SFKGLE001552","1","07:08:00","03:00:00","2018-08-25 09:12:35");
INSERT INTO `staffattendence` VALUES("SFKGLE001553","1","07:00:00","06:00:00","2018-08-25 09:12:35");
INSERT INTO `staffattendence` VALUES("SFKGMA001563","1","08:00:00","04:00:00","2018-08-25 09:13:35");



DROP TABLE IF EXISTS `staffbankdetails`;

CREATE TABLE `staffbankdetails` (
  `staffID` char(12) NOT NULL,
  `bank` varchar(50) DEFAULT NULL,
  `accno` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `staffborrow`;

CREATE TABLE `staffborrow` (
  `copyID` int(11) NOT NULL,
  `isbn` char(12) NOT NULL,
  `staffID` char(12) NOT NULL,
  `dateBorrowed` date NOT NULL,
  `dateReturned` date NOT NULL,
  `fine` double NOT NULL,
  PRIMARY KEY (`copyID`,`isbn`,`staffID`,`dateBorrowed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staffborrow` VALUES("1","yh1246","SFKGLE001553","2018-08-06","2018-08-22","0");
INSERT INTO `staffborrow` VALUES("2","b12031","SFKGLE001553","2018-08-15","2018-08-24","0");



DROP TABLE IF EXISTS `staffcontact`;

CREATE TABLE `staffcontact` (
  `staffID` char(12) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `officephone` int(11) DEFAULT NULL,
  `mobilephone` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staffcontact` VALUES("SFKGAD001325","mrosenstengel0@mayoclinic.com","814987465",NULL,"8864 Swallow Avenue",NULL);
INSERT INTO `staffcontact` VALUES("SFKGAD001365","mjeune4@va.gov","814796743",NULL,"28 Declaration Road",NULL);
INSERT INTO `staffcontact` VALUES("SFKGAD001366","Simon@simon.lk","814687987",NULL,"No 2, Simon Road, Kandy",NULL);
INSERT INTO `staffcontact` VALUES("SFKGLE000007","nvidia@grapics.com","716448679",NULL,"No, Katugasthota Road, Kandy",NULL);
INSERT INTO `staffcontact` VALUES("SFKGLE001553","Jus@gmail.com","812266887",NULL,"No, 277, Katugasthota Road, Kandy",NULL);
INSERT INTO `staffcontact` VALUES("SFKGLE001564","pasi@sl.com","815799878",NULL,"No 5, Colombo road, kandy",NULL);
INSERT INTO `staffcontact` VALUES("SFKGMA001569","Jacob@gmail.com","717543465",NULL,"No. 255, Pera road , Kandy",NULL);



DROP TABLE IF EXISTS `staffdumb`;

CREATE TABLE `staffdumb` (
  `staffId` char(12) NOT NULL,
  `nameInFull` varchar(250) DEFAULT NULL,
  `nameWithInit` varchar(150) DEFAULT NULL,
  `managedBy` char(12) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `post` varchar(100) NOT NULL DEFAULT 'Staff Member',
  `dob` date NOT NULL,
  `nic` varchar(9) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `jobtype` varchar(50) DEFAULT NULL,
  `marital_stat` varchar(50) DEFAULT NULL,
  `dateUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `centerId` char(12) DEFAULT NULL,
  `thumb` varchar(150) NOT NULL DEFAULT 'images/icons/user.png'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staffdumb` VALUES("SFKGLE000002","Davy Schiller","D Schiller","SFKGLE000005","M","","2018-08-07","965252225","Sri Lankan","","S","2018-08-30 04:58:24",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFKGLE000005","Rose Schiller","R Schiller","SFKGLE000005","F","","2018-08-02","20125224V","Sri Lankan","","S","2018-08-30 05:25:23",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFKGLE000007","Amal Hermiston","D Hermiston","SFKGLE000005","M","","2018-08-02","201252777","Sri Lankan","","S","2018-08-30 08:07:19",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFLLLL123457","A . Amal Perera","","SFLLLL123456","M","","2018-09-02","965264242","","","","2018-09-14 07:24:54",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFLLLL121312","A . Amal Perera",NULL,"SFLLLL123456","M","accountant","2018-09-26","962322512",NULL,"permenent",NULL,"2018-09-23 14:13:03",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFKGMN418574","dishara fernando",NULL,"SFLLLL123456","F","accountant","2018-09-02","965264242",NULL,"permenent",NULL,"2018-09-28 13:18:10",NULL,"images/icons/user.png");
INSERT INTO `staffdumb` VALUES("SFLLLL789785","Sunimal Perera",NULL,"SFLLLL123456","M","accountant","2018-09-02","965264242",NULL,"permenent",NULL,"2018-09-28 13:19:22",NULL,"images/icons/user.png");



DROP TABLE IF EXISTS `stafflibrarymember`;

CREATE TABLE `stafflibrarymember` (
  `staffID` char(12) NOT NULL,
  `receiptNo` char(10) NOT NULL,
  `dateRegistered` date NOT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `stafflibrarymember` VALUES("SFKGLE002277","LIB1224","2018-09-07");
INSERT INTO `stafflibrarymember` VALUES("SFKGLE002297","LIB1239","2018-08-30");
INSERT INTO `stafflibrarymember` VALUES("SFKGLE002298","LIB4557","2018-09-20");
INSERT INTO `stafflibrarymember` VALUES("SFKGLE002299","LIB1223","2018-09-10");
INSERT INTO `stafflibrarymember` VALUES("SFKGLE123456","LIB1237","2018-08-01");



DROP TABLE IF EXISTS `staffreserved`;

CREATE TABLE `staffreserved` (
  `copyID` int(11) NOT NULL,
  `isbn` char(13) NOT NULL,
  `staffID` char(12) NOT NULL,
  `reservedDate` date NOT NULL,
  PRIMARY KEY (`copyID`,`isbn`,`staffID`,`reservedDate`),
  KEY `isbn` (`isbn`),
  KEY `staffID` (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staffreserved` VALUES("5","td4556","SFKGLE001553","2018-08-15");



DROP TABLE IF EXISTS `studcompletecourse`;

CREATE TABLE `studcompletecourse` (
  `stuID` char(12) NOT NULL,
  `courseID` varchar(10) NOT NULL,
  `certificateIssueDate` date NOT NULL,
  `certificateNo` varchar(15) NOT NULL,
  `collectorName` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`stuID`,`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studcompletecourse` VALUES("STKGCV","CV001","2018-10-02","ETS012","Kasun","1");
INSERT INTO `studcompletecourse` VALUES("STKGCV002222","CV002","2018-10-02","ETS015","Nirmala","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT001111","IT01","2018-10-02","ETS001","Chamika","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT001212","IT01","2018-10-02","ETS010","Himeshi","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT001452","001","2018-08-31","ct125555","student","0");
INSERT INTO `studcompletecourse` VALUES("STKGIT001452","IT01","2018-08-31","CN125555","Asoka","0");
INSERT INTO `studcompletecourse` VALUES("STKGIT002222","IT02","2018-02-01","ETS002","Iresha","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT003333","IT03","2018-09-02","ETS003","Indika","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT003636","IT01","2018-10-02","ETS015","Hansi","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT006666","IT05","2018-03-01","ETS006","Iresha","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT00999","IT02","2018-04-25","ETS008","Amashi","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT009999","IT06","2018-06-01","ETS010","Achintha","1");
INSERT INTO `studcompletecourse` VALUES("STKGIT2424","IT001","2018-10-02","ETS012","Silva","1");
INSERT INTO `studcompletecourse` VALUES("STKGQS0001","QS02","2018-10-02","ETS011","Mashi","1");
INSERT INTO `studcompletecourse` VALUES("STKGQS004444","QS01","2018-05-03","ETS004","Asiri","1");
INSERT INTO `studcompletecourse` VALUES("STKGQS005555","QS02","2018-07-01","ETS005","chami","1");
INSERT INTO `studcompletecourse` VALUES("STKGQS007777","QS03","2018-01-01","ETS009","Sajith","1");
INSERT INTO `studcompletecourse` VALUES("STKGQS0099","QS01","2018-09-03","ACTA001","Perera","0");



DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `stuID` char(12) NOT NULL,
  `nameWithInit` varchar(100) NOT NULL,
  `nameInFull` varchar(250) NOT NULL,
  `dob` date NOT NULL,
  `nic` varchar(10) NOT NULL,
  `ol` tinyint(1) NOT NULL,
  `al` tinyint(1) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `thumb` varchar(100) NOT NULL DEFAULT 'images/icons/user.png',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `courseID` varchar(15) NOT NULL,
  PRIMARY KEY (`stuID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `student` VALUES("STKGET001212","J.D. Salinger","Jerome David Salinger","1919-08-15","986774958V","1","0","852/sd/weqw hgfds, vfd hgfd","1","2018-08-25 15:27:17","2018-08-29 14:45:19","images/icons/user.png","0","");
INSERT INTO `student` VALUES("STKGET001214","E.E. Cummings","Edward Estlin Cummings","1995-08-02","958006968V","1","1","jhgf jhgf gfd hgf gfc hgf hgf","1","2018-02-12 15:27:17","2018-09-28 16:37:12","images/icons/user.png","1","");
INSERT INTO `student` VALUES("STKGET002222","Cummings E.E","Edward Estlin Cummings","1995-08-02","958006968V","1","1","Hettimulla,Kegalle","1","2018-07-25 15:27:17","2018-10-01 22:01:27","0","1","IT02");
INSERT INTO `student` VALUES("STKGET003333","J.D. Salinger","Jerome David Salinger","1919-08-15","986774958V","1","0","Colombo Road,Kurunagala","1","2018-08-25 15:27:17","2018-10-01 17:21:25","0","1","QS01");
INSERT INTO `student` VALUES("STKGIT001111","Subasinghe N.A.C.K.","chamika kawshalya Subasinghe","1995-09-22","957773160V","1","1","Kegalle,Mawanelle","1","2018-06-01 22:50:10","2018-10-01 22:01:07","images/icons/user.png","1","IT01");
INSERT INTO `student` VALUES("STKGIT001284","E.B. White.","Elwyn Brooks white","1997-08-15","971508797V","1","1","kb/24/kegalle town kegalle.","1","2018-01-08 15:27:17","2018-09-28 16:37:01","images/icons/user.png","1","");
INSERT INTO `student` VALUES("STKGIT001452","H.P. Lovecraft ","Howard Phillips Lovecraft","1996-07-13","965228473V","1","0","524/A jiduhweurf jqhevd","0","2018-08-25 15:27:17","2018-08-29 14:45:37","images/icons/user.png","1","");
INSERT INTO `student` VALUES("STKGIT001453","E.T.S.Perara","Emma Tiffani Sarah Perera","0000-00-00","961571162V","0","1","Kandy RD, Colombo","1","2018-02-06 14:44:40","2018-09-28 16:37:21","images/icons/user.png","1","");
INSERT INTO `student` VALUES("STKGIT004444","Kumara N.K","Nalin Kusum Kumara","1995-10-03","951234597V","1","0","Mawanella,Kegalle","1","2018-10-01 22:58:38","2018-10-01 17:28:38","images/icons/user.png","1","IT01");
INSERT INTO `student` VALUES("STKGIT005555","Thennakoon M.K","Monojie Kumari","1997-11-01","976899097V","1","1","Thannekumbura,Digana","0","2018-10-01 23:09:32","2018-10-01 17:39:32","images/icons/user.png","1","IT01");
INSERT INTO `student` VALUES("STKGIT006666","Thennakoon A.L","Achintha Lakmal Thennakoon","1995-09-22","952345678V","1","1","Kuburugama.Kandy","1","2018-05-01 23:05:51","2018-10-01 22:00:52","images/icons/user.png","1","QS02");
INSERT INTO `student` VALUES("STKGIT007777","Hewage A.S.S.","Asiri shashikumar sampath Hewage","1996-08-20","961234567V","1","1","Gampola,Kandy","1","2018-03-01 22:58:38","2018-10-01 22:00:28","images/icons/user.png","1","IT02");
INSERT INTO `student` VALUES("STKGIT008801","Perera P.S.","Prabath Sachinka","1997-08-03","971456789V","1","1","Mathale road,Kandy","1","2018-10-02 03:36:51","2018-10-01 22:06:51","images/icons/user.png","1","IT02");
INSERT INTO `student` VALUES("STKGIT008888","White E.B","Elwyn Brooks white","1997-08-15","971508797V","1","1","kb/24/kegalle town kegalle.","1","2018-09-25 15:27:17","2018-10-01 22:01:41","0","1","IT01");
INSERT INTO `student` VALUES("STKGIT009901","Aberathna A.B.C.D","Asanka Bagya Chamod Dakshila","1995-03-01","952314567V","1","0","kandy road,Colombo","1","2018-10-02 03:36:51","2018-10-01 22:06:51","images/icons/user.png","1","IT01");
INSERT INTO `student` VALUES("STKGIT009999","Ganegala I.K.","Iresha Kumari Ganegala","1997-08-02","974536180V","1","1","Ambathanna,Kandy","0","2018-02-01 22:50:10","2018-10-01 22:00:17","images/icons/user.png","1","IT01");
INSERT INTO `student` VALUES("STKGQS002222","Welideniya L","Laksara Walideniya","1995-03-01","952345670V","1","1","Thannekumbura,Kandy","1","2018-04-01 23:05:51","2018-10-01 22:00:43","images/icons/user.png","1","QS01");
INSERT INTO `student` VALUES("STKGQS002412","Subasinghe N.A.A.I","Asanka Indrajith","1989-01-16","871245678V","1","1","Dembatagolla,Undugoda","1","2018-09-05 00:00:00","2018-10-01 22:10:00","images/icons/user.png","1","CV001");



DROP TABLE IF EXISTS `studentattendence`;

CREATE TABLE `studentattendence` (
  `stuID` char(12) NOT NULL,
  `courseID` varchar(10) NOT NULL,
  `moduleID` varchar(10) NOT NULL,
  `arrived` tinyint(4) NOT NULL DEFAULT '0',
  `departure` tinyint(4) NOT NULL DEFAULT '0',
  `arivalTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `depatureTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `present` tinyint(1) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`stuID`,`courseID`,`moduleID`),
  KEY `courseID` (`courseID`),
  KEY `moduleID` (`moduleID`),
  CONSTRAINT `studentattendence_ibfk_1` FOREIGN KEY (`stuID`) REFERENCES `student` (`stuID`),
  CONSTRAINT `studentattendence_ibfk_2` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`),
  CONSTRAINT `studentattendence_ibfk_3` FOREIGN KEY (`moduleID`) REFERENCES `module` (`moduleID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentattendence` VALUES("STKGET001212","002","ET1012","1","0","2018-08-25 02:00:00","2018-08-25 04:00:00","0","0000-00-00");
INSERT INTO `studentattendence` VALUES("STKGET001214","002","ET1012","1","0","2018-08-25 02:00:00","2018-08-25 04:00:00","0","0000-00-00");
INSERT INTO `studentattendence` VALUES("STKGIT001452","001","IT1010","1","0","2018-08-25 03:00:00","2018-08-25 05:00:00","0","0000-00-00");



DROP TABLE IF EXISTS `studentborrow`;

CREATE TABLE `studentborrow` (
  `copyID` int(11) NOT NULL,
  `isbn` char(13) NOT NULL,
  `studentID` char(12) NOT NULL,
  `dateBorrowed` date NOT NULL,
  `dateReturned` date NOT NULL,
  `fine` double NOT NULL,
  PRIMARY KEY (`copyID`,`isbn`,`studentID`,`dateBorrowed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentborrow` VALUES("3","yh12546","STKGIT001284","2018-07-09","2018-08-01","10");
INSERT INTO `studentborrow` VALUES("4","b12031","STKGET001214","2018-08-05","2018-08-24","0");



DROP TABLE IF EXISTS `studentexam`;

CREATE TABLE `studentexam` (
  `examID` varchar(10) NOT NULL,
  `stuID` char(12) NOT NULL,
  `marks` double DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`examID`,`stuID`),
  KEY `stuID` (`stuID`),
  CONSTRAINT `studentexam_ibfk_1` FOREIGN KEY (`examID`) REFERENCES `exam` (`ExamID`),
  CONSTRAINT `studentexam_ibfk_2` FOREIGN KEY (`stuID`) REFERENCES `student` (`stuID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentexam` VALUES("ET12","STKGET001212","40","2018-08-25 15:37:46");
INSERT INTO `studentexam` VALUES("IT10","STKGIT001284",NULL,"2018-08-25 15:37:46");



DROP TABLE IF EXISTS `studentlibrarymember`;

CREATE TABLE `studentlibrarymember` (
  `studentID` char(12) NOT NULL,
  `receiptNo` char(10) NOT NULL,
  `dateRegistered` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentlibrarymember` VALUES("STKGBM001144","LIB3344","2018-08-20");
INSERT INTO `studentlibrarymember` VALUES("STKGBM001145","LIB4558","2018-09-12");
INSERT INTO `studentlibrarymember` VALUES("STKGBM001148","LIB1233","2018-09-12");
INSERT INTO `studentlibrarymember` VALUES("STKGBM001199","LIB1229","2018-09-11");
INSERT INTO `studentlibrarymember` VALUES("STKGBM002298","LIB1239","2018-08-31");



DROP TABLE IF EXISTS `studentpayment`;

CREATE TABLE `studentpayment` (
  `paymentID` int(11) NOT NULL,
  `stuID` char(12) NOT NULL,
  `paidDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `billBookNo` varchar(20) NOT NULL,
  `paidAmount` double NOT NULL,
  `pendingAmount` double NOT NULL,
  `installmentType` varchar(50) NOT NULL,
  `totalAmount` double NOT NULL,
  `transactionID` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `installments` int(11) NOT NULL,
  `courseID` varchar(15) NOT NULL,
  `reg_fee` double NOT NULL,
  PRIMARY KEY (`paymentID`,`transactionID`),
  UNIQUE KEY `stuID` (`stuID`),
  UNIQUE KEY `stuID_2` (`stuID`),
  UNIQUE KEY `stuID_3` (`stuID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentpayment` VALUES("0","STKGIT000011","2018-10-01 16:47:50","01","5000","661666","1","666666","0","0","0","","500");
INSERT INTO `studentpayment` VALUES("1","STKGET001214","2018-08-25 11:38:01","01","20000","80000","New","100000","0","0","0","","0");
INSERT INTO `studentpayment` VALUES("2","STKGIT001284","2018-08-25 12:16:23","00125","250000","250000","New","500000","0","0","0","","0");



DROP TABLE IF EXISTS `studentregister`;

CREATE TABLE `studentregister` (
  `stuID` char(12) NOT NULL,
  `courseID` varchar(10) NOT NULL,
  `dateRegistered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`stuID`,`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `studentregister` VALUES("STKGET001212","002","2018-03-12 00:00:00");
INSERT INTO `studentregister` VALUES("STKGIT001284","011","2017-07-11 00:00:00");
INSERT INTO `studentregister` VALUES("STKGIT001452","001","2017-07-13 00:00:00");



DROP TABLE IF EXISTS `support_tickets`;

CREATE TABLE `support_tickets` (
  `messageId` int(11) NOT NULL,
  `threadId` int(11) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `subject` varchar(250) NOT NULL,
  `priority` tinyint(4) NOT NULL DEFAULT '3',
  `sender` int(11) DEFAULT NULL,
  `responder` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`messageId`,`threadId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `support_tickets` VALUES("1","4","test message her this is sgrgaeg asrg arg asg ag aga rgrg arg","1","Test message subject here","1",NULL,"0","2018-08-11 13:54:32");
INSERT INTO `support_tickets` VALUES("2","4","same thread message this is sgrgaeg asrg arg asg ag aga rgrg arg","0","Test message subject here","2",NULL,"0","2018-08-28 22:41:15");
INSERT INTO `support_tickets` VALUES("3","4","closed support ticketssf sfg awgwr gr wgw rgrw gwgw gsrg r","0","Closed support ticket ","1",NULL,"0","2018-08-11 13:54:32");
INSERT INTO `support_tickets` VALUES("4","2","message goes here is a good message sliit guys","1","test subject sdf sdf s fgs ","3",NULL,"0","2018-08-28 22:38:08");
INSERT INTO `support_tickets` VALUES("4","3","thread 2 message goes herebedf efwef sdf sdf sd fgsfgv sgsdr gwsg wrfgvs rfrw w","1","thread 2 message goes herebedf efwef","3",NULL,"0","2018-08-11 13:54:32");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `authId` tinyint(4) NOT NULL DEFAULT '1',
  `UID` char(12) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(150) NOT NULL,
  PRIMARY KEY (`authId`,`UID`),
  UNIQUE KEY `UID` (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES("0","","","2018-10-02 06:39:01","");
INSERT INTO `users` VALUES("1","SFKGAD001325","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-25 17:49:21","");
INSERT INTO `users` VALUES("2","SFKGLE001553","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 22:41:53","");
INSERT INTO `users` VALUES("3","SFKGMA001563","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-28 00:46:16","");
INSERT INTO `users` VALUES("4","SFKGLE001564","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 20:52:32","");
INSERT INTO `users` VALUES("5","SFKGAD001365","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 22:41:53","");
INSERT INTO `users` VALUES("6","SFKGAD001366","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 22:40:44","");
INSERT INTO `users` VALUES("7","SFKGMA001567","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 22:46:24","");
INSERT INTO `users` VALUES("8","SFKGLE001552","$2y$10$C.6k/pf6QLhnXz6UZVHELOs3qDQT9oVyq4EXNrxAnGnFA3wA2pt9K","2018-08-29 20:53:39","");



DROP TABLE IF EXISTS `visitors`;

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(11) NOT NULL,
  `firstVisit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastVisit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visits` int(11) NOT NULL,
  `ref` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `visitors` VALUES("1","::1","2018-09-29 20:50:25","2018-10-01 10:12:23","49","");
INSERT INTO `visitors` VALUES("2","192.168.1.3","2018-09-29 20:52:21","2018-09-29 23:23:16","7","http://192.168.1.2:8082/ets/");
INSERT INTO `visitors` VALUES("3","","2018-09-29 22:06:05","2018-09-29 17:00:00","5","");
INSERT INTO `visitors` VALUES("4","","2018-09-29 22:06:05","2018-09-29 05:00:00","8","");
