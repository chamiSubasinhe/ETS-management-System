<?php
require_once "../koolreport/autoload.php";

use \koolreport\processes\Filter;
use \koolreport\processes\Grouping;
use \koolreport\processes\Sort;
use \koolreport\processes\Group;
use \koolreport\processes\CalculatedColumn;
use \koolreport\processes\AggregatedColumn;



class PettycashList extends \koolreport\KoolReport
{
    function settings()
    {
        return array(
            "dataSources"=>array(
                "pettycash"=>array(
                    'connectionString' => 'mysql:host=localhost;dbname=ets',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8',
                )
            )
        );
    }
    function setup()
    {
        $this->src("pettycash")
        
		->query("select date, category,reciptID,amountNeeded from pettycash")
		
		->pipe(new CalculatedColumn(array(
		"rowNum"=>"{#}"
		)))

		
		//to display the total 
		->pipe(new AggregatedColumn(array(
		"total"=>array("sum","amountNeeded")
		)))
		
		/*->pipe(new Group( array(
		"by"=>"reciptID",
		"sum"=>"amountNeeded"
		)))
		*/
		->pipe(new Sort (array(
		"amountNeeded"=>"asc"
		)))
		

           
		
        ->pipe($this->dataStore("pettycash"));
		
		
		
		
		
		
		
    }
}