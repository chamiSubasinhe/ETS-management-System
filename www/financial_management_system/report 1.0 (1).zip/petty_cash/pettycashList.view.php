<?php 
    use \koolreport\widgets\koolphp\Table;
?>
<html>
    <head>
        <title>petty_cash_amount</title>
    </head>
    <body>
    <body>
	
	
        <h1 style="color:MediumSeaGreen;">Expenses - report</h1>																				
        <?php
		
		
        Table::create(array( 
            "dataStore"=>$this->dataStore("pettycash"),
			
			//apply to <table tag>
			"cssClass"=>array(
            "table"=>"color"
			),
			
			"showHeader"=>true,
			"showFooter"=>"bottom",
					
				
				
				"columns"=>array(
					"reciptID"=>array(
						"label"=>" ID"
				),
				
				"date"=>array(
					"label"=>"Date"
				),	
				
				"category"=>array(
					"label"=>"Category"
				),	
				
				"amountNeeded"=>array(
					"type"=>"number",
					"label"=>"  Amount",
					"prefix"=>"RS ",
					"footer"=>"sum",
					"footerText"=>"@value",
				)
			),
				
				
					
					
				
			
			

			

			

       	
        ));
		

		
		
        ?>	
			<style >
            .color 
            {
                border: 1px solid black;
            }
			
			th, td 
			{
				padding: 15px;
				text-align: left;
				border-bottom: 1px solid #ddd;
				
			}
			tr:hover {background-color: #f5f5f5;}
			tr:nth-child(even) {background-color: #f2f2f2;}
			
			th
			{
				background-color: DodgerBlue;
				color: white;
			}
			
			</style>
		
    </body>
</html>
