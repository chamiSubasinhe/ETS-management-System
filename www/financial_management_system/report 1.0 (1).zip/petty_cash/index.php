<?php 
    require_once "PettycashList.php";
    $report = new PettycashList;
    $report->run()->render();
?>