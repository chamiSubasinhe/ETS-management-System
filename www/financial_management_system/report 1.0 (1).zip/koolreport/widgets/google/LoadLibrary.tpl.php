<script type='text/javascript'>
  //google.charts.load('<?php echo $zone; ?>', {'packages':<?php echo json_encode($packages); ?>});
</script>