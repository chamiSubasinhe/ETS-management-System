<?php 
    use \koolreport\widgets\koolphp\Table;
?>
<html>
    <head>
        <title>BILL REPORT</title>
    </head>
    <body>
    <body>
	
	
        <h1 style="color:MediumSeaGreen;">Bill Expenses - Report</h1>																				
        <?php
		
		
        Table::create(array( 
            "dataStore"=>$this->dataStore("bills"),
			
			//apply to <table tag>
			"cssClass"=>array(
            "table"=>"color"
			),
			
			"showHeader"=>true,
			"showFooter"=>"bottom",
					
				
				
				"columns"=>array(
					"billNo"=>array(
						"label"=>" BILL NO"
				),
				
				"dateAdded"=>array(
					"label"=>"DATE"
				),	
				
				"category"=>array(
					"label"=>"CATEGORY"
				),	
				
				"amount"=>array(
					"type"=>"number",
					"label"=>" AMOUNT",
					"prefix"=>"RS ",
					"footer"=>"sum",
					"footerText"=>"@value",
				)
			),
				
				
					
					
				
			
			

			

			

       	
        ));
		

		
		
        ?>	
			<style >
            .color 
            {
                border: 1px solid black;
            }
			
			th, td 
			{
				padding: 15px;
				text-align: left;
				border-bottom: 1px solid #ddd;
				
			}
			tr:hover {background-color: #f5f5f5;}
			tr:nth-child(even) {background-color: #f2f2f2;}
			
			th
			{
				background-color: DodgerBlue;
				color: white;
			}
			
			</style>
		
    </body>
</html>
