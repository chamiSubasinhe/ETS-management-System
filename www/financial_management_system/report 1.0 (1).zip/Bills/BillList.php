<?php
require_once "../koolreport/autoload.php";

use \koolreport\processes\Filter;
use \koolreport\processes\Grouping;
use \koolreport\processes\Sort;
use \koolreport\processes\Group;
use \koolreport\processes\CalculatedColumn;
use \koolreport\processes\AggregatedColumn;



class BillList extends \koolreport\KoolReport
{
    function settings()
    {
        return array(
            "dataSources"=>array(
                "bills"=>array(
                    'connectionString' => 'mysql:host=localhost;dbname=ets',
                    'username' => 'root',
                    'password' => '',
                    'charset' => 'utf8',
                )
            )
        );
    }
    function setup()
    {
        $this->src("bills")
        
		->query("select dateAdded, category,billNo,amount from bills")
		
		->pipe(new CalculatedColumn(array(
		"rowNum"=>"{#}"
		)))

		
		//to display the total 
		->pipe(new AggregatedColumn(array(
		"total"=>array("sum","amount")
		)))
		
		/*->pipe(new Group( array(
		"by"=>"reciptID",
		"sum"=>"amountNeeded"
		)))
		*/
		->pipe(new Sort (array(
		"amount"=>"asc"
		)))
		

           
		
        ->pipe($this->dataStore("bills"));
		
		
		
		
		
		
		
    }
}