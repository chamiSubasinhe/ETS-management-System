<?php 
    require_once "BillList.php";
    $report = new BillList;
    $report->run()->render();
?>