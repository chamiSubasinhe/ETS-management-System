<div class="search-bar">
        <div class="search-icon">
            <i class="material-icons"></i>
        </div>
		<form action="search.php" method="POST">
        <input type="text" name="search" placeholder="START TYPING...">
		</form>
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>