<div class="legal">
                <div class="copyright">
                    &copy; 2018 <a href="javascript:void(0);"><?php echo $settingsArr['Owner'];?></a>.
                </div>
                <div class="version">
                    <b>Version:  6.8</b>
                </div>
            </div>
			
<?php
 ob_clean();
?>