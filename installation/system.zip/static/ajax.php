<script>


//<div id="txtHint"><b>Person info will be listed here...</b></div>


//<form>
//<select name="users" onchange="showUser(this.value)">
 // <option value="">Select a person:</option>
  //<option value="1">Peter Griffin</option>
  //<option value="2">Lois Griffin</option>
  //<option value="3">Joseph Swanson</option>
  //<option value="4">Glenn Quagmire</option>
  //</select>
//</form>

function getVote(int) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("poll").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
  xmlhttp.send();
}




function showSettings(str) {
    if (str == "") {
        document.getElementById("settingsTable").innerHTML = "Error retrieving data!";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("settingsTable").innerHTML = this.responseText;
            }
        };
		//xmlhttp.open("GET","getSettings.php?q="+str,true);
        xmlhttp.open("GET","getSettings.php,true);
        xmlhttp.send();
    }
}

</script>